/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     2018/1/27 21:06:29                           */
/*==============================================================*/


alter table MANAGER_SELECT
   drop constraint FK_MANAGER__REFERENCE_STU_INFO;

alter table MANAGER_SELECT
   drop constraint FK_MANAGER__REFERENCE_MANAGER_;

alter table STU_INFO
   drop constraint FK_STU_INFO_REFERENCE_MANAGER_;

alter table STU_SELECTED
   drop constraint FK_STU_SELE_REFERENCE_MANAGER_;

alter table STU_SELECTED
   drop constraint FK_STU_SELE_REFERENCE_STU_INFO;

drop table MANAGER_INFO cascade constraints;

drop table MANAGER_SELECT cascade constraints;

drop table STU_INFO cascade constraints;

drop table STU_SELECTED cascade constraints;

/*==============================================================*/
/* Table: MANAGER_INFO                                          */
/*==============================================================*/
create table MANAGER_INFO 
(
   MANAGER_ID           NUMBER               not null,
   MANAGER_NAME         VARCHAR2(15 CHAR)    not null,
   MANAGER_TEL          VARCHAR2(11)         not null,
   MANAGER_TYPE         VARCHAR2(2)          not null,
   MANAGER_ACCOUNT      VARCHAR2(30)         not null,
   MANAGER_PWD          VARCHAR2(32)         not null,
   MANAGER_COND         VARCHAR2(50 CHAR),
   MANAGER_TITLE        VARCHAR2(50 CHAR),
   MANAGER_DETAIL       VARCHAR2(50 CHAR),
   MANAGER_RATEDNUM     VARCHAR2(2),
   MANAGER_SELECTED     VARCHAR2(2),
   constraint PK_MANAGER_INFO primary key (MANAGER_ID)
);

comment on column MANAGER_INFO.MANAGER_TYPE is
'1-----ϵͳ����Ա
2-----��ʦ
';

/*==============================================================*/
/* Table: MANAGER_SELECT                                        */
/*==============================================================*/
create table MANAGER_SELECT 
(
   SELECT_ID            NUMBER               not null,
   STU_ID               NUMBER,
   MANAGER_ID           NUMBER,
   SELECT_TIME          DATE                 not null,
   SELECT_YPPE          VARBINARY(1)         not null,
   constraint PK_MANAGER_SELECT primary key (SELECT_ID)
);

comment on column MANAGER_SELECT.SELECT_YPPE is
'1---ѡ��
2---��ѡ';

/*==============================================================*/
/* Table: STU_INFO                                              */
/*==============================================================*/
create table STU_INFO 
(
   STU_ID               NUMBER               not null,
   MANAGER_ID           NUMBER,
   STU_NAME             VARCHAR2(15 CHAR)    not null,
   STU_IDCARD           VARCHAR2(18)         not null,
   STU_TEL              VARCHAR2(11)         not null,
   STU_WECHAT           VARCHAR2(30),
   STU_QQ               VARCHAR2(15),
   STU_STATE            VARCHAR2(2)          not null,
   STU_POLOTICS         NUMBER(3),
   STU_ENGLISH          NUMBER(4,1),
   STU_MATH             NUMBER(3),
   STU_MAJOR            NUMBER(3),
   STU_RESUB1           NUMBER(4,1),
   STU_RESUB2           NUMBER(4,1),
   STU_REENGLISH        NUMBER(4,1),
   STU_INTERVIEW        NUMBER(4,1),
   STU_ACCOUNT          VARCHAR2(20)         not null,
   STU_PWD              VARCHAR2(30)         not null,
   STU_CANDIDATE        VARCHAR2(15)         not null,
   constraint PK_STU_INFO primary key (STU_ID)
);

comment on column STU_INFO.STU_STATE is
'1----������
2-----��ע��';

/*==============================================================*/
/* Table: STU_SELECTED                                          */
/*==============================================================*/
create table STU_SELECTED 
(
   CHOOSE_ID            NUMBER               not null,
   STU_ID               NUMBER,
   MANAGER_ID           NUMBER,
   CHOOSE_DATE          DATE                 not null,
   CHOOSE_TYPE          VARCHAR2(2)          not null,
   constraint PK_STU_SELECTED primary key (CHOOSE_ID)
);

comment on column STU_SELECTED.CHOOSE_TYPE is
'1-----ѡ��
2-----��ѡ';

alter table MANAGER_SELECT
   add constraint FK_MANAGER__REFERENCE_STU_INFO foreign key (STU_ID)
      references STU_INFO (STU_ID);

alter table MANAGER_SELECT
   add constraint FK_MANAGER__REFERENCE_MANAGER_ foreign key (MANAGER_ID)
      references MANAGER_INFO (MANAGER_ID);

alter table STU_INFO
   add constraint FK_STU_INFO_REFERENCE_MANAGER_ foreign key (MANAGER_ID)
      references MANAGER_INFO (MANAGER_ID);

alter table STU_SELECTED
   add constraint FK_STU_SELE_REFERENCE_MANAGER_ foreign key (MANAGER_ID)
      references MANAGER_INFO (MANAGER_ID);

alter table STU_SELECTED
   add constraint FK_STU_SELE_REFERENCE_STU_INFO foreign key (STU_ID)
      references STU_INFO (STU_ID);

