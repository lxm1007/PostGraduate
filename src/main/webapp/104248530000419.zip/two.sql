/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     2018/1/27 21:16:49                           */
/*==============================================================*/


alter table MANAGER_SELECT
   drop constraint FK_MANAGER__REFERENCE_STU_INFO;

alter table MANAGER_SELECT
   drop constraint FK_MANAGER__REFERENCE_MANAGER_;

alter table SCOTT.STU_INFO
   drop constraint FK_STU_INFO_REFERENCE_MANAGER_;

alter table SCOTT.STU_SELECTED
   drop constraint FK_STU_SELE_REFERENCE_MANAGER_;

alter table SCOTT.STU_SELECTED
   drop constraint FK_STU_SELE_REFERENCE_STU_INFO;

drop table SCOTT.MANAGER_INFO cascade constraints;

drop table MANAGER_SELECT cascade constraints;

drop table SCOTT.STU_INFO cascade constraints;

drop table SCOTT.STU_SELECTED cascade constraints;

drop sequence SCOTT.SEQ_MANAGER_INFO;

drop sequence SCOTT.SEQ_ROOM_ID;

drop sequence SCOTT.SEQ_STU_INFO;

drop sequence SCOTT.SEQ_STU_SELECTED;

drop sequence SCOTT.SEQ_VIP_ID;

drop sequence SCOTT.USER_SEQ;

drop user SCOTT;

/*==============================================================*/
/* User: SCOTT                                                  */
/*==============================================================*/
create user SCOTT 
  identified by "";

create sequence SCOTT.SEQ_MANAGER_INFO
MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20;

create sequence SCOTT.SEQ_ROOM_ID
MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20;

create sequence SCOTT.SEQ_STU_INFO
MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20;

create sequence SCOTT.SEQ_STU_SELECTED
MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20;

create sequence SCOTT.SEQ_VIP_ID
MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20;

create sequence SCOTT.USER_SEQ
MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 CACHE 20;

/*==============================================================*/
/* Table: MANAGER_INFO                                          */
/*==============================================================*/
create table SCOTT.MANAGER_INFO 
(
   MANAGER_ID           NUMBER               not null,
   MANAGER_NAME         VARCHAR2(15 CHAR)    not null,
   MANAGER_TEL          VARCHAR2(11 BYTE)    not null,
   MANAGER_TYPE         VARCHAR2(40 BYTE)    not null,
   MANAGER_ACCOUNT      VARCHAR2(30 BYTE)    not null,
   MANAGER_PWD          VARCHAR2(32 BYTE)    not null,
   MANAGER_COND         VARCHAR2(40 CHAR),
   MANAGER_TITLE        VARCHAR2(50 CHAR),
   MANAGER_DETAIL       VARCHAR2(500 CHAR),
   MANAGER_RATEDNUM     VARCHAR2(2 BYTE),
   MANAGER_SELECTED     VARCHAR2(2 BYTE),
   MANAGER_STATE        VARCHAR2(2 BYTE),
   MANAGER_SEX          VARCHAR2(4 BYTE),
   MANAGER_MENTORTYPE   VARCHAR2(40 BYTE),
   MANAGER_MAJOR        VARCHAR2(40 BYTE),
   constraint PK_MANAGER_INFO primary key (MANAGER_ID),
   constraint SYS_C0013015 check ("MANAGER_ID" IS NOT NULL),
   constraint SYS_C0013016 check ("MANAGER_NAME" IS NOT NULL),
   constraint SYS_C0013017 check ("MANAGER_TEL" IS NOT NULL),
   constraint SYS_C0013018 check ("MANAGER_TYPE" IS NOT NULL),
   constraint SYS_C0013019 check ("MANAGER_ACCOUNT" IS NOT NULL),
   constraint SYS_C0013020 check ("MANAGER_PWD" IS NOT NULL)
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT;

comment on column SCOTT.MANAGER_INFO.MANAGER_TYPE is
'1-----ϵͳ����Ա
2-----��ʦ';

comment on column SCOTT.MANAGER_INFO.MANAGER_STATE is
'1----��Ϣδ����
2----��Ϣ������
3---ѧ��δ����
4---ѧ��������';

comment on column SCOTT.MANAGER_INFO.MANAGER_MENTORTYPE is
'��ʦ����';

/*==============================================================*/
/* Table: MANAGER_SELECT                                        */
/*==============================================================*/
create table MANAGER_SELECT 
(
   SELECT_ID            NUMBER               not null,
   STU_ID               NUMBER,
   MANAGER_ID           NUMBER,
   SELECT_TIME          DATE                 not null,
   SELECT_TYPE          VARCHAR2(1)          not null,
   constraint PK_MANAGER_SELECT primary key (SELECT_ID)
);

/*==============================================================*/
/* Table: STU_INFO                                              */
/*==============================================================*/
create table SCOTT.STU_INFO 
(
   STU_ID               NUMBER               not null,
   MANAGER_ID           NUMBER,
   STU_NAME             VARCHAR2(15 CHAR)    not null,
   STU_IDCARD           VARCHAR2(18 BYTE),
   STU_TEL              VARCHAR2(11 BYTE),
   STU_WECHAT           VARCHAR2(30 BYTE),
   STU_QQ               VARCHAR2(15 BYTE),
   STU_STATE            VARCHAR2(2 BYTE)     not null,
   STU_POLOTICS         NUMBER(3)            not null,
   STU_ENGLISH          NUMBER(4,1)          not null,
   STU_SUB1             NUMBER(3)            not null,
   STU_SUB2             NUMBER(3)            not null,
   STU_RESUB1           NUMBER(4,1),
   STU_RESUB2           NUMBER(4,1),
   STU_REENGLISH        NUMBER(4,1),
   STU_INTERVIEW        NUMBER(4,1),
   STU_ACCOUNT          VARCHAR2(20 BYTE),
   STU_PWD              VARCHAR2(32 BYTE),
   STU_CANDIDATE        VARCHAR2(15 BYTE)    not null,
   STU_SEX              VARCHAR2(1 CHAR)     not null,
   STU_TOTALSCORE1      NUMBER(4,1)          not null,
   STU_TOTALSCORE2      NUMBER(4,1),
   STU_SPECIALTYCODE    VARCHAR2(6 BYTE)     not null,
   STU_MAJORNAME        VARCHAR2(20 CHAR)    not null,
   STU_MAJORCONDITION   VARCHAR2(40 CHAR)    not null,
   STU_GRADUATIONSCHOOL VARCHAR2(40 CHAR)    not null,
   STU_GRADUATIONMAJOR  VARCHAR2(20 CHAR)    not null,
   STU_GRADUATIONTIME   VARCHAR2(6 BYTE)     not null,
   STU_MASTERTYPE       VARCHAR2(2 CHAR)     not null,
   STU_STUDYTYPE        VARCHAR2(4 CHAR)     not null,
   STU_HONOR            VARCHAR2(500 CHAR),
   STU_EMAIL            VARCHAR2(30 BYTE),
   constraint PK_STU_INFO primary key (STU_ID),
   constraint SYS_C0013022 check ("STU_ID" IS NOT NULL),
   constraint SYS_C0013023 check ("STU_NAME" IS NOT NULL),
   constraint SYS_C0013026 check ("STU_STATE" IS NOT NULL),
   constraint SYS_C0013112 check ("STU_POLOTICS" IS NOT NULL),
   constraint SYS_C0013113 check ("STU_ENGLISH" IS NOT NULL),
   constraint SYS_C0013114 check ("STU_SUB1" IS NOT NULL),
   constraint SYS_C0013115 check ("STU_SUB2" IS NOT NULL),
   constraint SYS_C0013116 check ("STU_CANDIDATE" IS NOT NULL),
   constraint SYS_C0013119 check ("STU_SEX" IS NOT NULL),
   constraint SYS_C0013120 check ("STU_TOTALSCORE1" IS NOT NULL),
   constraint SYS_C0013121 check ("STU_SPECIALTYCODE" IS NOT NULL),
   constraint SYS_C0013122 check ("STU_MAJORNAME" IS NOT NULL),
   constraint SYS_C0013123 check ("STU_MAJORCONDITION" IS NOT NULL),
   constraint SYS_C0013124 check ("STU_GRADUATIONSCHOOL" IS NOT NULL),
   constraint SYS_C0013125 check ("STU_GRADUATIONMAJOR" IS NOT NULL),
   constraint SYS_C0013126 check ("STU_GRADUATIONTIME" IS NOT NULL),
   constraint SYS_C0013127 check ("STU_MASTERTYPE" IS NOT NULL),
   constraint SYS_C0013128 check ("STU_STUDYTYPE" IS NOT NULL)
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT;

comment on column SCOTT.STU_INFO.STU_STATE is
'1----������
2-----��ע��';

comment on column SCOTT.STU_INFO.STU_POLOTICS is
'����';

comment on column SCOTT.STU_INFO.STU_ENGLISH is
'Ӣ��';

comment on column SCOTT.STU_INFO.STU_SUB1 is
'��ѧ';

comment on column SCOTT.STU_INFO.STU_SUB2 is
'רҵ��';

comment on column SCOTT.STU_INFO.STU_ACCOUNT is
'�˻�';

comment on column SCOTT.STU_INFO.STU_PWD is
'����';

comment on column SCOTT.STU_INFO.STU_CANDIDATE is
'����';

comment on column SCOTT.STU_INFO.STU_SEX is
'�Ա�';

comment on column SCOTT.STU_INFO.STU_TOTALSCORE1 is
'�����ܷ�';

comment on column SCOTT.STU_INFO.STU_TOTALSCORE2 is
'�����ܷ�';

comment on column SCOTT.STU_INFO.STU_SPECIALTYCODE is
'רҵ����';

comment on column SCOTT.STU_INFO.STU_MAJORNAME is
'רҵרҵ����';

comment on column SCOTT.STU_INFO.STU_MAJORCONDITION is
'�о�����';

comment on column SCOTT.STU_INFO.STU_GRADUATIONSCHOOL is
'��ҵѧУ';

comment on column SCOTT.STU_INFO.STU_GRADUATIONMAJOR is
'��ҵ��ҵרҵ';

comment on column SCOTT.STU_INFO.STU_GRADUATIONTIME is
'��ҵʱ��';

comment on column SCOTT.STU_INFO.STU_MASTERTYPE is
'ѧ˶ר˶';

comment on column SCOTT.STU_INFO.STU_STUDYTYPE is
'ȫ����,��ȫ����';

/*==============================================================*/
/* Table: STU_SELECTED                                          */
/*==============================================================*/
create table SCOTT.STU_SELECTED 
(
   CHOOSE_ID            NUMBER               not null,
   STU_ID               NUMBER,
   MANAGER_ID           NUMBER,
   CHOOSE_DATE          DATE                 not null,
   CHOOSE_TYPE          VARCHAR2(2 BYTE)     not null,
   constraint PK_STU_SELECTED primary key (CHOOSE_ID),
   constraint SYS_C0013030 check ("CHOOSE_ID" IS NOT NULL),
   constraint SYS_C0013031 check ("CHOOSE_DATE" IS NOT NULL),
   constraint SYS_C0013032 check ("CHOOSE_TYPE" IS NOT NULL)
)
TABLESPACE "USERS"
LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536 
  NEXT 1048576 
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT;

comment on column SCOTT.STU_SELECTED.CHOOSE_TYPE is
'1-----ѡ��
2-----��ѡ';

alter table MANAGER_SELECT
   add constraint FK_MANAGER__REFERENCE_STU_INFO foreign key (STU_ID)
      references SCOTT.STU_INFO (STU_ID);

alter table MANAGER_SELECT
   add constraint FK_MANAGER__REFERENCE_MANAGER_ foreign key (MANAGER_ID)
      references SCOTT.MANAGER_INFO (MANAGER_ID);

alter table SCOTT.STU_INFO
   add constraint FK_STU_INFO_REFERENCE_MANAGER_ foreign key (MANAGER_ID)
      references SCOTT.MANAGER_INFO (MANAGER_ID);

alter table SCOTT.STU_SELECTED
   add constraint FK_STU_SELE_REFERENCE_MANAGER_ foreign key (MANAGER_ID)
      references SCOTT.MANAGER_INFO (MANAGER_ID);

alter table SCOTT.STU_SELECTED
   add constraint FK_STU_SELE_REFERENCE_STU_INFO foreign key (STU_ID)
      references SCOTT.STU_INFO (STU_ID);

